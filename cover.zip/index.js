require('dotenv').config();
const express = require('express');
const axios = require('axios');
const fs = require('fs');
const cors = require('cors');
const QRCode = require('qrcode');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

let orders = [];
if (fs.existsSync('./orders.json')) {
  try { orders = JSON.parse(fs.readFileSync('./orders.json')); } catch {}
}
const saveOrders = () =>
  fs.writeFileSync('./orders.json', JSON.stringify(orders, null, 2));

/* ================= GET SERVICES ================= */
app.get('/api/services', async (req, res) => {
  try {
    const r = await axios.post(
      'https://www.fayupedia.id/api/services',
      {
        api_id: process.env.FAYU_ID,
        api_key: process.env.FAYU_API
      }
    );

    if (!r.data.status) return res.status(400).json(r.data);

    const grouped = {};
    r.data.services.forEach(s => {
      const cat = s.category || 'Other';
      if (!grouped[cat]) grouped[cat] = [];
      grouped[cat].push({
        id: s.id,
        name: s.name,
        price: Number(s.price)
      });
    });

    res.json(grouped);
  } catch (e) {
    res.status(500).json({ msg: 'Gagal ambil layanan' });
  }
});

/* ================= ORDER ================= */
app.post('/api/order', async (req, res) => {
  const { user, service, target, quantity } = req.body;
  if (!user || !service || !target || !quantity)
    return res.status(400).json({ status: false, msg: 'Parameter kurang' });

  try {
    // 1️⃣ Order Fayu
    const fayu = await axios.post(
      'https://www.fayupedia.id/api/order',
      {
        api_id: process.env.FAYU_ID,
        api_key: process.env.FAYU_API,
        service,
        target,
        quantity
      }
    );

    if (!fayu.data.status) return res.status(400).json(fayu.data);

    const orderId = fayu.data.order;
    const price = Number(fayu.data.price || 0) * quantity;

    // 2️⃣ Create QRIS Pakasir
    const pakasir = await axios.post(
      'https://app.pakasir.com/api/transactioncreate/qris',
      {
        project: process.env.PAKASIR_PROJECT,
        order_id: orderId,
        amount: price
      },
      {
        headers: {
          Authorization: `Bearer ${process.env.PAKASIR_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const paymentCode = pakasir.data.payment.payment_code;

    // 3️⃣ Encode QR
    const qrImage = await QRCode.toDataURL(paymentCode);

    // 4️⃣ Simpan order
    orders.push({
      order_id: orderId,
      user,
      service,
      target,
      quantity,
      amount: price,
      status: 'PENDING'
    });
    saveOrders();

    res.json({
      status: true,
      order_id: orderId,
      qris: {
        qr_image: qrImage,
        payment_code: paymentCode
      },
      detail: `Bayar Rp ${price.toLocaleString('id-ID')}`
    });

  } catch (e) {
    console.error(e);
    res.status(500).json({ status: false, msg: 'Order gagal' });
  }
});

/* ================= WEBHOOK ================= */
app.post('/pakasir-webhook', (req, res) => {
  const payment = req.body;
  if (!payment.order_id || !payment.status) return res.sendStatus(200);

  const order = orders.find(o => o.order_id == payment.order_id);
  if (!order) return res.sendStatus(200);

  if (['PAID', 'completed'].includes(payment.status)) {
    order.status = 'PAID';
    order.paid_at = new Date().toISOString();
    saveOrders();
  }

  res.sendStatus(200);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () =>
  console.log(`🚀 Server running on http://localhost:${PORT}`)
);