const menuBtn = document.getElementById('menuBtn');
const sidebar = document.getElementById('sidebar');
if(menuBtn) menuBtn.addEventListener('click', () => sidebar.classList.toggle('active'));

// Login
const loginForm = document.getElementById('loginForm');
if(loginForm){
  loginForm.addEventListener('submit', async e=>{
    e.preventDefault();
    const data = Object.fromEntries(new FormData(loginForm).entries());
    const res = await fetch('/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)});
    const json = await res.json();
    alert(json.message);
    if(json.success) window.location='/';
  });
}

// Register
const registerForm = document.getElementById('registerForm');
if(registerForm){
  registerForm.addEventListener('submit', async e=>{
    e.preventDefault();
    const data = Object.fromEntries(new FormData(registerForm).entries());
    const res = await fetch('/api/auth/register',{method:'POST',headers:{'Content-Type':'application/json'}, body: JSON.stringify(data)});
    const json = await res.json();
    alert(json.message);
    if(json.success) window.location='/login';
  });
}