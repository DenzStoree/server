const express = require('express');
const router = express.Router();
const User = require('../models/user');
const bcrypt = require('bcrypt');

// Register
router.post('/register', async (req, res) => {
  try {
    const { username, password, phone } = req.body;
    if(!username || !password) return res.status(400).json({ success:false, message:"Username & Password required" });

    const hashed = await bcrypt.hash(password, 10);
    const user = new User({ username, password: hashed, phone });
    await user.save();
    res.json({ success: true, message: 'User registered!' });
  } catch (e) {
    res.status(400).json({ success: false, error: e.message });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({ username });
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ success: false, message: 'Wrong password' });

    res.json({ success: true, message: 'Login successful', user: { username, phone: user.phone } });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

module.exports = router;