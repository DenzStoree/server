const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const https = require('https');
const path = require('path');

const app = express();
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// ===== DATA =====
let orders = [];
let config = {
    dns: "",
    fayu_id: "",
    fayu_api: "",
    project: "",
    pakasir_api: ""
};

// ===== LOAD CONFIG DARI GITHUB =====
async function loadConfig() {
    try {
        const res = await axios.get(
            'https://raw.githubusercontent.com/DenzStoree/denzofc/main/config.json',
            { httpsAgent: new https.Agent({ rejectUnauthorized: false }) }
        );

        let data = typeof res.data === 'string' ? JSON.parse(res.data) : res.data;

        if (data && data.apikey) {
            config = {
                dns: data.apikey.dns || "",
                fayu_id: data.apikey.fayu_id || "",
                fayu_api: data.apikey.fayu_api || "",
                project: data.apikey.project || "",
                pakasir_api: data.apikey.pakasir_api || ""
            };
            console.log("Config loaded from GitHub:", config);
        } else {
            console.warn("Config from GitHub empty, using defaults.");
        }
    } catch (e) {
        console.error("Failed to load config:", e.message);
    }
}
loadConfig();
setInterval(loadConfig, 5 * 60 * 1000);

// ===== CREATE ORDER =====
app.post('/order/create', async (req, res) => {
    try {
        const { service_id, target, qty, total } = req.body;
        if (!service_id || !target || !qty || !total) {
            return res.status(400).json({ error: "Invalid order data" });
        }

        const order_id = "ORD" + Date.now();

        // ===== REQUEST QRIS PAKASIR =====
        let qrisNumber = "dummy_qris";
        try {
            const pakasirResp = await axios.post('https://app.pakasir.com/api/transactioncreate/qris', {
                project: config.project,
                order_id,
                amount: total,
                api_key: config.pakasir_api
            });
            qrisNumber = pakasirResp.data.payment?.payment_number || qrisNumber;
        } catch (e) {
            console.error("Pakasir request failed:", e.message);
        }

        orders.push({
            order_id,
            service_id,
            target,
            qty,
            total,
            status: "pending",
            created_at: new Date().toISOString()
        });

        res.json({ order_id, qris: qrisNumber });

    } catch (e) {
        console.error("Order create error:", e.message);
        res.status(500).json({ error: "Failed to create order" });
    }
});

// ===== GET ORDERS =====
app.get('/order/list', (req, res) => {
    res.json(orders);
});

// ===== WEBHOOK PAKASIR =====
app.post('/webhook/pakasir', async (req, res) => {
    try {
        const { order_id, status } = req.body;
        let order = orders.find(o => o.order_id === order_id);
        if (!order) return res.sendStatus(200);

        if (["PAID", "completed"].includes(status) && order.status !== "paid") {
            order.status = "paid";
            order.paid_at = new Date().toISOString();

            // ===== REQUEST KE FAYUPEDIA =====
            try {
                const fayuResp = await axios.post('https://www.fayupedia.id/api/order', {
                    api_id: config.fayu_id,
                    api_key: config.fayu_api,
                    service: order.service_id,
                    target: order.target,
                    quantity: order.qty
                });
                console.log(`Fayupedia order success:`, fayuResp.data);
            } catch (e) {
                console.error("Fayupedia request failed:", e.message);
            }
        }

        res.sendStatus(200);
    } catch (e) {
        console.error("Webhook error:", e.message);
        res.sendStatus(500);
    }
});

// ===== START SERVER =====
app.listen(3000, () => console.log("Server running on port 3000..."));