const ordersDiv = document.getElementById('orders');

async function loadOrders() {
  const res = await fetch('/order/list');
  const data = await res.json();
  ordersDiv.innerHTML = '';
  data.forEach(o => {
    const card = document.createElement('div');
    card.className = 'order-card ' + (o.status || 'pending');
    card.innerHTML = `
      <b>Order ID:</b> ${o.order_id}<br>
      <b>Service:</b> ${o.service_id}<br>
      <b>Target:</b> ${o.target}<br>
      <b>Qty:</b> ${o.qty}<br>
      <b>Total:</b> ${o.total}<br>
      <b>Status:</b> ${o.status}
    `;
    ordersDiv.appendChild(card);
  });
}

document.getElementById('orderForm').addEventListener('submit', async e => {
  e.preventDefault();
  const f = e.target;
  const data = {
    service_id: f.service_id.value,
    target: f.target.value,
    qty: f.qty.value,
    total: f.total.value
  };
  
  const res = await fetch('/order/create', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(data)
  });
  
  const json = await res.json();
  if(json.error){
    alert(json.error);
    return;
  }

  alert(`Order created!\nID: ${json.order_id}\nQRIS: ${json.qris}`);
  loadOrders();
  f.reset();
});

loadOrders();
setInterval(loadOrders, 5000); // auto refresh orders tiap 5 detik