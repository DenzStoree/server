require('dotenv').config();
const express = require('express');
const axios = require('axios');
const fs = require('fs');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

let orders = [];
if(fs.existsSync('./orders.json')){
  try { orders = JSON.parse(fs.readFileSync('./orders.json')); } catch {}
}
function saveOrders(data){ fs.writeFileSync('./orders.json', JSON.stringify(data,null,2)); }

let saldo = {};
function addSaldo(user, amount){ saldo[user] = (saldo[user]||0) + amount; }
function getSaldo(user){ return saldo[user]||0; }

// ==== FAYU API ====
// GET daftar layanan
app.get('/api/services', async (req,res)=>{
  try{
    const r = await axios.post('https://www.fayupedia.id/api/services',{
      api_id: process.env.FAYU_ID,
      api_key: process.env.FAYU_API
    });
    res.json(r.data);
  }catch(e){
    res.status(500).json({status:false,msg:'Gagal ambil layanan',err:e.message});
  }
});

// POST order + QRIS Pakasir
app.post('/api/order', async (req,res)=>{
  const {user, service, target, quantity} = req.body;
  if(!user||!service||!target||!quantity) return res.status(400).json({status:false,msg:'Parameter kurang'});
  try{
    // 1️⃣ Order ke Fayu
    const r = await axios.post('https://www.fayupedia.id/api/order',{
      api_id: process.env.FAYU_ID,
      api_key: process.env.FAYU_API,
      service,
      target,
      quantity
    });
    if(!r.data.status) return res.status(400).json(r.data);
    const orderId = r.data.order;

    // 2️⃣ Generate QRIS Pakasir
    const qrisRes = await axios.post(
      'https://app.pakasir.com/api/transactioncreate/qris',
      {
        project: process.env.PAKASIR_PROJECT,
        order_id: orderId,
        amount: quantity * r.data.price, 
        api_key: process.env.PAKASIR_API_KEY
      },
      { headers: {"Content-Type":"application/json","Accept":"application/json"} }
    );
    const qris = qrisRes.data.payment; // sesuai doc Pakasir

    // Simpan order sementara
    orders.push({
      order_id: orderId,
      user,
      service,
      target,
      quantity,
      status:'PENDING',
      amount:quantity*r.data.price
    });
    saveOrders(orders);

    res.json({status:true,order_id:orderId,qris,detail:`Service: ${service}, Target: ${target}, Qty: ${quantity}`});
  }catch(e){
    console.error(e.message);
    res.status(500).json({status:false,msg:'Gagal order',err:e.message});
  }
});

// ==== PAKASIR WEBHOOK ====
app.post("/pakasir-webhook", (req,res)=>{
  console.log("Webhook masuk:",req.body);
  const payment = req.body;
  if(!payment.order_id || !payment.status) return res.sendStatus(200);

  let order = orders.find(o=>o.order_id==payment.order_id);
  if(!order) return res.sendStatus(200);

  if(["PAID","completed"].includes(payment.status) && order.status!=="PAID"){
    order.status="PAID";
    order.paid_at = new Date().toISOString();
    addSaldo(order.user, order.amount);

    console.log(`✅ Order PAID, saldo ${order.user} +${order.amount}`);
    saveOrders(orders);
  }

  res.sendStatus(200);
});

const PORT = process.env.PORT||3000;
app.listen(PORT,()=>console.log(`Server running on http://localhost:${PORT}`));