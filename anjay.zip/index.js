require('dotenv').config();
const express = require('express');
const axios = require('axios');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Endpoint get services dari Fayu
app.get('/api/services', async (req, res) => {
  try {
    const response = await axios.post('https://www.fayupedia.id/api/services', {
      api_id: process.env.FAYU_API_ID,
      api_key: process.env.FAYU_API_KEY
    });
    res.json(response.data);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({status:false,msg:'Gagal ambil layanan'});
  }
});

// Endpoint order
app.post('/api/order', async (req,res)=>{
  const {service,target,quantity} = req.body;
  try{
    // 1️⃣ Buat order di Fayu
    const orderRes = await axios.post('https://www.fayupedia.id/api/order', {
      api_id: process.env.FAYU_API_ID,
      api_key: process.env.FAYU_API_KEY,
      service,
      target,
      quantity
    });

    if(!orderRes.data.status) return res.status(400).json(orderRes.data);

    const orderId = orderRes.data.order;

    // 2️⃣ Buat QRIS di Pakasir
    const qrisRes = await axios.post(process.env.PAKASIR_API, {
      key: process.env.PAKASIR_KEY,
      amount: req.body.price || 0, 
      description: `Order #${orderId} SMM Panel`
    });

    res.json({
      status:true,
      order_id: orderId,
      qris:qrisRes.data.number_payment,
      detail:`Service ID: ${service}, Target: ${target}, Quantity: ${quantity}`
    });
  } catch(err){
    console.error(err.message);
    res.status(500).json({status:false,msg:'Gagal proses order'});
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log(`Server running on http://localhost:${PORT}`));